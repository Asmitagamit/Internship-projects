﻿namespace Mission.Entity.Models.MissionSkillModels
{
    public class AddMissionSkillRequestModel
    {
        public string SkillName { get; set; }

        public string Status { get; set; }
    }
}
