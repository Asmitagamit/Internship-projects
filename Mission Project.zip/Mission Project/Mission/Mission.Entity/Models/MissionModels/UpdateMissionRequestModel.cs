﻿namespace Mission.Entity.Models.MissionModels
{
    public class UpdateMissionRequestModel : AddMissionRequestModel
    {
        public int Id { get; set; }
    }
}
