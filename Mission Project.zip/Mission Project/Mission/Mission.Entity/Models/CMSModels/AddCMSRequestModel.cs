﻿namespace Mission.Entity.Models.CMSModels
{
    public class AddCMSRequestModel
    {
        public string Title { get; set; }

        public string Description { get; set; }

        public string Slug { get; set; }

        public string Status { get; set; }
    }
}
